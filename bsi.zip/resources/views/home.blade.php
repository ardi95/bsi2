@extends('layouts.app')

@section('css')
    <style type="text/css">
        nav{
            margin-bottom: 0px !important;
        }
        .item1{
            background: url('{{ asset('carousel/1.jpg') }}') 50% 50% no-repeat; 
            /*width: 100%; */
            /*height: 554px;*/
            background-size: cover;
        }

        .owl-carousel .item img{
            /*display: block;*/
            width: 100%;
            height: 550px;
        }
    </style>
@endsection

@section('content')
    <div class="owl-carousel owl-theme">
        <div class="item"><img src="{{ asset('carousel/1.jpg') }}"></div>
        <div class="item"><img src="{{ asset('carousel/2.jpg') }}"></div>
        <div class="item"><img src="{{ asset('carousel/3.jpg') }}"></div>
    </div>
    <div class="container-fluid">
        <h2 class="text-primary text-center">Selamat datang di website Pemesanan Pagar</h2>
    </div>
@endsection

@section('scripts')
    <script type="text/javascript">
        $('.owl-carousel').owlCarousel({
            loop:true,
            items:1,
            autoplay:true,
            responsive:{
                0:{
                    items:1
                }
            }
        });
    </script>
    
@endsection