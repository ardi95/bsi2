<div class="btn-group">
	<a href="<?php echo e(route('bayar.show',$id)); ?>" class="btn btn-info">Lihat Pesanan</a>
	<?php if($statusbayar == '0'): ?>
		<button class="btn btn-primary btn-upload" onclick="tes('<?php echo e($id); ?>')" data-toggle="modal" data-target="#myModal">Konfirmasi</button>
	<?php endif; ?>
</div>