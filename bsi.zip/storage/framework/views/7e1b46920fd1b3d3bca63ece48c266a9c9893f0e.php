<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<ul class="breadcrumb">
					<li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
					<li class="active">Keranjang Belanja</li>
				</ul>
				<div class="panel panel-default">
					<div class="panel-heading">
						<h2 class="panel-title">Keranjang Belanja</h2>
					</div>
					<div class="panel-body">
						<?php echo $html->table(['class'=>'table-striped']); ?>

						<div class="row">
							<div class="col-lg-6">
								<h3>Total Pembayaran: <span class="label label-primary">Rp. <?php echo e(number_format($total,0,",",".")); ?></span></h3>
								<p><a href="<?php echo e(route('productuser.index')); ?>" class="btn btn-default"><i class="fas fa-angle-double-left"></i>&nbsp; Lanjut Belanja</a></p>
							</div>
							<div class="col-lg-6 col-right-cart">\
								<?php echo Form::open(['url' => route('bayar.store'), 'method' => 'post', 'class'=>'form-horizontal']); ?>

									<p class="text-right"><button class="btn btn-warning btn-lg" type="submit"><i class="far fa-check-circle fa-lg"></i>&nbsp; Checkout</button></p>
								<?php echo Form::close(); ?>

							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

	<?php echo $html->scripts(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>