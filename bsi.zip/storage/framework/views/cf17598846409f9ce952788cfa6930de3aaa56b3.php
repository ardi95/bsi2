<div class="btn-group">
	<a href="<?php echo e(route('konfirmasi.show',$id)); ?>" class="btn btn-info">Lihat pemesanan</a>
	<?php if($statusbayar == 1): ?>
		<button onclick="konfirmasi('<?php echo e($id); ?>')" type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
  			Konfirmasi
		</button>

	<?php endif; ?>
</div>