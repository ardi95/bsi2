<?php $__env->startSection('css'); ?>
    <style type="text/css">
        nav{
            margin-bottom: 0px !important;
        }
        .item1{
            background: url('<?php echo e(asset('carousel/1.jpg')); ?>') 50% 50% no-repeat; 
            /*width: 100%; */
            /*height: 554px;*/
            background-size: cover;
        }

        .owl-carousel .item img{
            /*display: block;*/
            width: 100%;
            height: 550px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="owl-carousel owl-theme">
        <div class="item"><img src="<?php echo e(asset('carousel/1.jpg')); ?>"></div>
        <div class="item"><img src="<?php echo e(asset('carousel/2.jpg')); ?>"></div>
        <div class="item"><img src="<?php echo e(asset('carousel/3.jpg')); ?>"></div>
    </div>
    <div class="container-fluid">
        <h2 class="text-primary text-center">Selamat datang di website Pemesanan Pagar</h2>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $('.owl-carousel').owlCarousel({
            loop:true,
            items:1,
            autoplay:true,
            responsive:{
                0:{
                    items:1
                }
            }
        });
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>