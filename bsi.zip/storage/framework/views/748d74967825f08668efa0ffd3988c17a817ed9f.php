<div class="form-group<?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
	<?php echo Form::label('nama', 'Nama', ['class'=>'col-md-2 control-label']); ?>

	<div class="col-md-4">
		<?php echo Form::text('nama', null, ['class'=>'form-control']); ?>

		<?php echo $errors->first('nama', '<p class="help-block">:message</p>'); ?>

	</div>
</div>
<div class="form-group<?php echo e($errors->has('harga') ? ' has-error' : ''); ?>">
	<?php echo Form::label('harga', 'Harga', ['class'=>'col-md-2 control-label']); ?>

	<div class="col-md-4">
		<?php echo Form::text('harga', null, ['class'=>'form-control']); ?>

		<?php echo $errors->first('harga', '<p class="help-block">:message</p>'); ?>

	</div>
</div>
<div class="form-group<?php echo e($errors->has('stok') ? ' has-error' : ''); ?>">
	<?php echo Form::label('stok', 'Stok', ['class'=>'col-md-2 control-label']); ?>

	<div class="col-md-4">
		<?php echo Form::text('stok', null, ['class'=>'form-control']); ?>

		<?php echo $errors->first('stok', '<p class="help-block">:message</p>'); ?>

	</div>
</div>
<div class="form-group<?php echo e($errors->has('deskripsi') ? ' has-error' : ''); ?>">
	<?php echo Form::label('deskripsi', 'Deskripsi', ['class'=>'col-md-2 control-label']); ?>

	<div class="col-md-4">
		<?php echo Form::textarea('deskripsi', null, ['class'=>'form-control']); ?>

		<?php echo $errors->first('deskripsi', '<p class="help-block">:message</p>'); ?>

	</div>
</div>
<div class="form-group<?php echo e($errors->has('foto') ? ' has-error' : ''); ?>">
	<?php echo Form::label('foto', 'Foto', ['class'=>'col-md-2 control-label']); ?>

	<div class="col-md-4">
		<?php echo Form::file('foto', ['class'=>'form-control']); ?>


		<?php if(isset($product) && $product->foto): ?>
			<p>
				<?php echo Html::image(asset('upload/'.$product->foto), null, ['class'=>'img-rounded img-responsive']); ?>

			</p>
		<?php endif; ?>

		<?php echo $errors->first('foto', '<p class="help-block">:message</p>'); ?>

	</div>
</div>

<div class="form-group">
	<div class="col-md-4 col-md-offset-2">
		<?php echo Form::submit('Simpan', ['class'=>'btn btn-primary']); ?>

	</div>
</div>